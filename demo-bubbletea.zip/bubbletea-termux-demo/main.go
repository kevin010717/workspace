package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	tea "charm.land/bubbletea/v2"
	"charm.land/lipgloss/v2"
)

const appName = "Bubble Tea Termux Demo"

type screen int

const (
	screenDashboard screen = iota
	screenTodos
	screenNotes
	screenHTTP
	screenJobs
	screenCommands
	screenSettings
	screenHelp
)

var screenNames = []string{
	"Dashboard",
	"Todos",
	"Notes",
	"HTTP",
	"Jobs",
	"Commands",
	"Settings",
	"Help",
}

type promptKind int

const (
	promptNone promptKind = iota
	promptAddTodo
	promptAddNoteTitle
	promptAddNoteBody
	promptEndpoint
	promptPkgInstall
	promptCurlURL
	promptGitRepo
	promptTarSource
	promptHTTPPort
	promptSSHHost
)

type Todo struct {
	ID      int64     `json:"id"`
	Text    string    `json:"text"`
	Done    bool      `json:"done"`
	Created time.Time `json:"created"`
}

type Note struct {
	ID      int64     `json:"id"`
	Title   string    `json:"title"`
	Body    string    `json:"body"`
	Created time.Time `json:"created"`
}

type Job struct {
	ID      int64   `json:"id"`
	Name    string  `json:"name"`
	Percent float64 `json:"percent"`
	Speed   float64 `json:"speed"`
	Running bool    `json:"running"`
	Done    bool    `json:"done"`
}

type appState struct {
	Todos        []Todo `json:"todos"`
	Notes        []Note `json:"notes"`
	Endpoint     string `json:"endpoint"`
	Theme        int    `json:"theme"`
	Compact      bool   `json:"compact"`
	AltScreen    bool   `json:"alt_screen"`
	LastCommand  string `json:"last_command"`
	ShowNoteBody bool   `json:"show_note_body"`
}

type inputState struct {
	Active      bool
	Kind        promptKind
	Title       string
	Placeholder string
	Value       string
}

type httpState struct {
	Loading   bool
	Result    string
	Status    string
	Elapsed   time.Duration
	Bytes     int
	LastError string
	UpdatedAt time.Time
}

type tickMsg time.Time

type savedMsg struct {
	Path string
	Err  error
}

type httpResultMsg struct {
	URL     string
	Status  string
	Elapsed time.Duration
	Bytes   int
	Body    string
	Err     error
}

type model struct {
	screen       screen
	width        int
	height       int
	cursor       map[screen]int
	logs         []string
	started      time.Time
	clock        time.Time
	input        inputState
	draftTitle   string
	state        appState
	jobs         []Job
	http         httpState
	quitting     bool
	status       string
	commandIndex int
}

type palette struct {
	Name   string
	Accent string
	Soft   string
	Muted  string
	Warn   string
	Bad    string
	Good   string
}

var palettes = []palette{
	{Name: "Neon", Accent: "#FF7CCB", Soft: "#7D56F4", Muted: "#626262", Warn: "#FFD866", Bad: "#FF5F87", Good: "#7DFFA3"},
	{Name: "Ocean", Accent: "#5FD7FF", Soft: "#5FAFFF", Muted: "#6C7086", Warn: "#F9E2AF", Bad: "#F38BA8", Good: "#A6E3A1"},
	{Name: "Amber", Accent: "#FFB86C", Soft: "#BD93F9", Muted: "#737373", Warn: "#F1FA8C", Bad: "#FF5555", Good: "#50FA7B"},
}

var (
	baseStyle = lipgloss.NewStyle()
)

func main() {
	m := initialModel()

	if _, err := tea.NewProgram(m).Run(); err != nil {
		fmt.Fprintf(os.Stderr, "failed to run %s: %v\n", appName, err)
		os.Exit(1)
	}
}

func initialModel() model {
	state, err := loadState()
	if err != nil {
		state = defaultState()
	}

	jobs := []Job{
		{ID: time.Now().UnixNano(), Name: "pkg upgrade cache", Percent: 0.23, Speed: 0.018, Running: true},
		{ID: time.Now().UnixNano() + 1, Name: "fetch GitHub API", Percent: 0.57, Speed: 0.011, Running: true},
		{ID: time.Now().UnixNano() + 2, Name: "build Go binary", Percent: 0.86, Speed: 0.006, Running: false},
	}

	m := model{
		screen:  screenDashboard,
		width:   92,
		height:  28,
		cursor:  map[screen]int{},
		logs:    []string{},
		started: time.Now(),
		clock:   time.Now(),
		state:   state,
		jobs:    jobs,
		http: httpState{
			Result: "Press f to fetch the configured endpoint.",
		},
		commandIndex: 0,
	}
	if err != nil {
		m.addLog("WARN", "state load failed: "+err.Error())
	} else {
		m.addLog("INFO", "state loaded from "+statePath())
	}
	return m
}

func defaultState() appState {
	return appState{
		Todos: []Todo{
			{ID: 1, Text: "Explore Model / Update / View", Done: false, Created: time.Now()},
			{ID: 2, Text: "Press ? to open the help screen", Done: true, Created: time.Now()},
			{ID: 3, Text: "Run this project in Termux", Done: false, Created: time.Now()},
		},
		Notes: []Note{
			{ID: 1, Title: "Welcome", Body: "This is a Bubble Tea v2 demo made for Termux. It saves data as JSON under your XDG data directory.", Created: time.Now()},
			{ID: 2, Title: "Learning idea", Body: "Try changing the Update function first. Add a new keybinding, then update the View.", Created: time.Now()},
		},
		Endpoint:  "https://api.github.com",
		Theme:     0,
		Compact:   false,
		AltScreen: true,
	}
}

func (m model) Init() tea.Cmd {
	return tickCmd()
}

func tickCmd() tea.Cmd {
	return tea.Tick(200*time.Millisecond, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if m.input.Active {
		return m.updateInput(msg)
	}

	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height
		return m, nil

	case tickMsg:
		m.clock = time.Time(msg)
		m.advanceJobs()
		return m, tickCmd()

	case savedMsg:
		if msg.Err != nil {
			m.status = "Save failed: " + msg.Err.Error()
			m.addLog("ERROR", m.status)
		} else {
			m.status = "Saved: " + msg.Path
			m.addLog("INFO", "state saved")
		}
		return m, nil

	case httpResultMsg:
		m.http.Loading = false
		m.http.Elapsed = msg.Elapsed
		m.http.UpdatedAt = time.Now()
		if msg.Err != nil {
			m.http.LastError = msg.Err.Error()
			m.http.Status = "ERROR"
			m.http.Result = msg.Err.Error()
			m.addLog("ERROR", "HTTP request failed: "+msg.Err.Error())
		} else {
			m.http.LastError = ""
			m.http.Status = msg.Status
			m.http.Bytes = msg.Bytes
			m.http.Result = msg.Body
			m.addLog("INFO", fmt.Sprintf("fetched %s in %s", msg.URL, msg.Elapsed.Round(time.Millisecond)))
		}
		return m, nil

	case tea.KeyPressMsg:
		return m.updateKey(msg.String())
	}

	return m, nil
}

func (m model) updateKey(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "ctrl+c", "q":
		m.quitting = true
		return m, tea.Quit
	case "?":
		m.screen = screenHelp
		return m, nil
	case "tab", "right", "l":
		m.nextScreen()
		return m, nil
	case "shift+tab", "left", "h":
		m.prevScreen()
		return m, nil
	case "T":
		m.state.Theme = (m.state.Theme + 1) % len(palettes)
		m.addLog("INFO", "theme changed to "+m.palette().Name)
		return m, saveStateCmd(m.state)
	case "S":
		m.addLog("INFO", "manual save requested")
		return m, saveStateCmd(m.state)
	}

	switch m.screen {
	case screenDashboard:
		return m.updateDashboard(key)
	case screenTodos:
		return m.updateTodos(key)
	case screenNotes:
		return m.updateNotes(key)
	case screenHTTP:
		return m.updateHTTP(key)
	case screenJobs:
		return m.updateJobs(key)
	case screenCommands:
		return m.updateCommands(key)
	case screenSettings:
		return m.updateSettings(key)
	case screenHelp:
		return m.updateHelp(key)
	default:
		return m, nil
	}
}

func (m model) updateDashboard(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "r":
		m.addLog("INFO", randomTip())
	case "s":
		return m, saveStateCmd(m.state)
	}
	return m, nil
}

func (m model) updateTodos(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		m.moveCursor(-1, len(m.state.Todos))
	case "down", "j":
		m.moveCursor(1, len(m.state.Todos))
	case "a":
		m.startInput(promptAddTodo, "Add todo", "Learn Bubble Tea updates…", "")
	case "space", "enter":
		i := m.cursor[m.screen]
		if i >= 0 && i < len(m.state.Todos) {
			m.state.Todos[i].Done = !m.state.Todos[i].Done
			m.addLog("INFO", "todo toggled")
			return m, saveStateCmd(m.state)
		}
	case "d", "backspace":
		i := m.cursor[m.screen]
		if i >= 0 && i < len(m.state.Todos) {
			removed := m.state.Todos[i].Text
			m.state.Todos = append(m.state.Todos[:i], m.state.Todos[i+1:]...)
			m.clampCursor(len(m.state.Todos))
			m.addLog("WARN", "deleted todo: "+removed)
			return m, saveStateCmd(m.state)
		}
	case "c":
		before := len(m.state.Todos)
		out := make([]Todo, 0, len(m.state.Todos))
		for _, t := range m.state.Todos {
			if !t.Done {
				out = append(out, t)
			}
		}
		m.state.Todos = out
		m.clampCursor(len(m.state.Todos))
		m.addLog("INFO", fmt.Sprintf("cleared %d done todos", before-len(out)))
		return m, saveStateCmd(m.state)
	}
	return m, nil
}

func (m model) updateNotes(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		m.moveCursor(-1, len(m.state.Notes))
	case "down", "j":
		m.moveCursor(1, len(m.state.Notes))
	case "a":
		m.draftTitle = ""
		m.startInput(promptAddNoteTitle, "New note title", "Termux idea", "")
	case "enter", "space":
		m.state.ShowNoteBody = !m.state.ShowNoteBody
		return m, saveStateCmd(m.state)
	case "d", "backspace":
		i := m.cursor[m.screen]
		if i >= 0 && i < len(m.state.Notes) {
			removed := m.state.Notes[i].Title
			m.state.Notes = append(m.state.Notes[:i], m.state.Notes[i+1:]...)
			m.clampCursor(len(m.state.Notes))
			m.addLog("WARN", "deleted note: "+removed)
			return m, saveStateCmd(m.state)
		}
	}
	return m, nil
}

func (m model) updateHTTP(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "e":
		m.startInput(promptEndpoint, "HTTP endpoint", "https://api.github.com", m.state.Endpoint)
	case "f", "enter":
		if strings.TrimSpace(m.state.Endpoint) == "" {
			m.addLog("WARN", "endpoint is empty")
			return m, nil
		}
		m.http.Loading = true
		m.http.Result = "Loading..."
		m.http.LastError = ""
		m.addLog("INFO", "fetching "+m.state.Endpoint)
		return m, fetchURLCmd(m.state.Endpoint)
	}
	return m, nil
}

func (m model) updateJobs(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "up", "k":
		m.moveCursor(-1, len(m.jobs))
	case "down", "j":
		m.moveCursor(1, len(m.jobs))
	case "n":
		m.jobs = append(m.jobs, Job{
			ID:      time.Now().UnixNano(),
			Name:    fmt.Sprintf("termux task %d", len(m.jobs)+1),
			Percent: rand.Float64() * 0.12,
			Speed:   0.004 + rand.Float64()*0.02,
			Running: true,
		})
		m.addLog("INFO", "new simulated job added")
	case "space", "enter":
		i := m.cursor[m.screen]
		if i >= 0 && i < len(m.jobs) && !m.jobs[i].Done {
			m.jobs[i].Running = !m.jobs[i].Running
			if m.jobs[i].Running {
				m.addLog("INFO", "job resumed: "+m.jobs[i].Name)
			} else {
				m.addLog("INFO", "job paused: "+m.jobs[i].Name)
			}
		}
	case "r":
		for i := range m.jobs {
			if m.jobs[i].Done {
				m.jobs[i].Percent = 0
				m.jobs[i].Done = false
				m.jobs[i].Running = true
			}
		}
		m.addLog("INFO", "completed jobs reset")
	case "d", "backspace":
		i := m.cursor[m.screen]
		if i >= 0 && i < len(m.jobs) {
			name := m.jobs[i].Name
			m.jobs = append(m.jobs[:i], m.jobs[i+1:]...)
			m.clampCursor(len(m.jobs))
			m.addLog("WARN", "removed job: "+name)
		}
	}
	return m, nil
}

func (m model) updateCommands(key string) (tea.Model, tea.Cmd) {
	count := len(commandTemplates())
	switch key {
	case "up", "k":
		m.commandIndex = clamp(m.commandIndex-1, 0, count-1)
	case "down", "j":
		m.commandIndex = clamp(m.commandIndex+1, 0, count-1)
	case "enter", "e":
		switch commandTemplates()[m.commandIndex].Kind {
		case promptPkgInstall:
			m.startInput(promptPkgInstall, "Package name", "git", "")
		case promptCurlURL:
			m.startInput(promptCurlURL, "Download URL", "https://example.com/file.zip", "")
		case promptGitRepo:
			m.startInput(promptGitRepo, "Git repository", "https://github.com/charmbracelet/bubbletea.git", "")
		case promptTarSource:
			m.startInput(promptTarSource, "Source path", ".", "")
		case promptHTTPPort:
			m.startInput(promptHTTPPort, "HTTP port", "8000", "8000")
		case promptSSHHost:
			m.startInput(promptSSHHost, "SSH target", "user@192.168.1.10", "")
		}
	case "c":
		if strings.TrimSpace(m.state.LastCommand) != "" {
			m.addLog("INFO", "copy command requested")
			return m, tea.SetClipboard(m.state.LastCommand)
		}
	}
	return m, nil
}

func (m model) updateSettings(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "1", "t":
		m.state.Theme = (m.state.Theme + 1) % len(palettes)
		m.addLog("INFO", "theme changed to "+m.palette().Name)
		return m, saveStateCmd(m.state)
	case "2", "c":
		m.state.Compact = !m.state.Compact
		m.addLog("INFO", fmt.Sprintf("compact mode: %v", m.state.Compact))
		return m, saveStateCmd(m.state)
	case "3", "a":
		m.state.AltScreen = !m.state.AltScreen
		m.addLog("INFO", fmt.Sprintf("alt screen: %v", m.state.AltScreen))
		return m, saveStateCmd(m.state)
	case "s":
		return m, saveStateCmd(m.state)
	}
	return m, nil
}

func (m model) updateHelp(key string) (tea.Model, tea.Cmd) {
	switch key {
	case "esc":
		m.screen = screenDashboard
	}
	return m, nil
}

func (m model) updateInput(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyPressMsg:
		key := msg.String()
		switch key {
		case "esc":
			m.input = inputState{}
			m.status = "Input cancelled"
			return m, nil
		case "enter":
			return m.commitInput()
		case "backspace", "ctrl+h":
			m.input.Value = removeLastRune(m.input.Value)
		case "ctrl+u":
			m.input.Value = ""
		case "space":
			m.input.Value += " "
		default:
			if isPrintableKey(key) {
				m.input.Value += key
			}
		}
	}
	return m, nil
}

func (m model) commitInput() (tea.Model, tea.Cmd) {
	value := strings.TrimSpace(m.input.Value)
	kind := m.input.Kind
	m.input = inputState{}

	switch kind {
	case promptAddTodo:
		if value == "" {
			m.status = "Empty todo ignored"
			return m, nil
		}
		m.state.Todos = append(m.state.Todos, Todo{
			ID:      time.Now().UnixNano(),
			Text:    value,
			Done:    false,
			Created: time.Now(),
		})
		m.cursor[screenTodos] = len(m.state.Todos) - 1
		m.addLog("INFO", "todo added")
		return m, saveStateCmd(m.state)

	case promptAddNoteTitle:
		if value == "" {
			value = "Untitled"
		}
		m.draftTitle = value
		m.startInput(promptAddNoteBody, "Note body", "Write one line; edit the code to make this multiline.", "")
		return m, nil

	case promptAddNoteBody:
		if value == "" {
			value = "(empty)"
		}
		m.state.Notes = append(m.state.Notes, Note{
			ID:      time.Now().UnixNano(),
			Title:   m.draftTitle,
			Body:    value,
			Created: time.Now(),
		})
		m.cursor[screenNotes] = len(m.state.Notes) - 1
		m.state.ShowNoteBody = true
		m.addLog("INFO", "note added")
		return m, saveStateCmd(m.state)

	case promptEndpoint:
		if value == "" {
			value = "https://api.github.com"
		}
		m.state.Endpoint = value
		m.addLog("INFO", "endpoint updated")
		return m, saveStateCmd(m.state)

	case promptPkgInstall:
		return m.setCommand("pkg install " + shellQuote(value))
	case promptCurlURL:
		name := filepath.Base(value)
		if name == "." || name == "/" || name == "" {
			name = "download.out"
		}
		return m.setCommand("curl -fL " + shellQuote(value) + " -o " + shellQuote(name))
	case promptGitRepo:
		return m.setCommand("git clone " + shellQuote(value))
	case promptTarSource:
		return m.setCommand("tar -czf backup.tar.gz " + shellQuote(value))
	case promptHTTPPort:
		if _, err := strconv.Atoi(value); err != nil {
			m.addLog("ERROR", "port must be a number")
			return m, nil
		}
		return m.setCommand("python -m http.server " + shellQuote(value) + " --directory .")
	case promptSSHHost:
		return m.setCommand("ssh -p 22 " + shellQuote(value))
	}

	return m, nil
}

func (m model) setCommand(cmd string) (tea.Model, tea.Cmd) {
	m.state.LastCommand = strings.TrimSpace(cmd)
	m.addLog("INFO", "command generated")
	return m, saveStateCmd(m.state)
}

func (m *model) startInput(kind promptKind, title, placeholder, value string) {
	m.input = inputState{
		Active:      true,
		Kind:        kind,
		Title:       title,
		Placeholder: placeholder,
		Value:       value,
	}
}

func (m *model) nextScreen() {
	m.screen = screen((int(m.screen) + 1) % len(screenNames))
}

func (m *model) prevScreen() {
	next := int(m.screen) - 1
	if next < 0 {
		next = len(screenNames) - 1
	}
	m.screen = screen(next)
}

func (m *model) moveCursor(delta, size int) {
	if size <= 0 {
		m.cursor[m.screen] = 0
		return
	}
	m.cursor[m.screen] = (m.cursor[m.screen] + delta + size) % size
}

func (m *model) clampCursor(size int) {
	if size <= 0 {
		m.cursor[m.screen] = 0
		return
	}
	m.cursor[m.screen] = clamp(m.cursor[m.screen], 0, size-1)
}

func (m *model) advanceJobs() {
	for i := range m.jobs {
		if !m.jobs[i].Running || m.jobs[i].Done {
			continue
		}
		m.jobs[i].Percent += m.jobs[i].Speed
		if m.jobs[i].Percent >= 1 {
			m.jobs[i].Percent = 1
			m.jobs[i].Done = true
			m.jobs[i].Running = false
			m.addLog("INFO", "job completed: "+m.jobs[i].Name)
		}
	}
}

func (m *model) addLog(level, text string) {
	line := fmt.Sprintf("%s %-5s %s", time.Now().Format("15:04:05"), level, text)
	m.logs = append(m.logs, line)
	if len(m.logs) > 9 {
		m.logs = m.logs[len(m.logs)-9:]
	}
}

func (m model) palette() palette {
	if m.state.Theme < 0 || m.state.Theme >= len(palettes) {
		return palettes[0]
	}
	return palettes[m.state.Theme]
}

func (m model) View() tea.View {
	content := m.render()
	v := tea.NewView(content)
	v.AltScreen = m.state.AltScreen
	return v
}

func (m model) render() string {
	p := m.palette()
	availableWidth := m.width
	if availableWidth < 60 {
		availableWidth = 60
	}

	header := m.renderHeader()
	nav := m.renderTabs()

	var body string
	switch m.screen {
	case screenDashboard:
		body = m.renderDashboard()
	case screenTodos:
		body = m.renderTodos()
	case screenNotes:
		body = m.renderNotes()
	case screenHTTP:
		body = m.renderHTTP()
	case screenJobs:
		body = m.renderJobs()
	case screenCommands:
		body = m.renderCommands()
	case screenSettings:
		body = m.renderSettings()
	case screenHelp:
		body = m.renderHelp()
	default:
		body = "Unknown screen"
	}

	footer := m.renderFooter()
	main := lipgloss.JoinVertical(lipgloss.Left, header, nav, body, footer)

	if m.input.Active {
		box := m.renderInputBox()
		main = lipgloss.JoinVertical(lipgloss.Left, main, box)
	}

	if m.status != "" && !m.input.Active {
		status := lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render(m.status)
		main = lipgloss.JoinVertical(lipgloss.Left, main, status)
	}

	return baseStyle.Width(availableWidth).Render(main)
}

func (m model) renderHeader() string {
	p := m.palette()
	title := lipgloss.NewStyle().
		Bold(true).
		Foreground(lipgloss.Color(p.Accent)).
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Padding(0, 2).
		Render(appName)

	info := lipgloss.NewStyle().
		Foreground(lipgloss.Color(p.Muted)).
		Render(fmt.Sprintf(" %s • %dx%d • %s", m.clock.Format("15:04:05"), m.width, m.height, p.Name))

	if m.width > 72 {
		return lipgloss.JoinHorizontal(lipgloss.Center, title, info)
	}
	return lipgloss.JoinVertical(lipgloss.Left, title, info)
}

func (m model) renderTabs() string {
	p := m.palette()
	parts := make([]string, 0, len(screenNames))
	for i, name := range screenNames {
		style := lipgloss.NewStyle().Padding(0, 1)
		if screen(i) == m.screen {
			style = style.Bold(true).
				Foreground(lipgloss.Color("#0D0D0D")).
				Background(lipgloss.Color(p.Accent))
		} else {
			style = style.Foreground(lipgloss.Color(p.Muted))
		}
		parts = append(parts, style.Render(name))
	}
	return lipgloss.NewStyle().MarginTop(1).Render(strings.Join(parts, " "))
}

func (m model) renderFooter() string {
	p := m.palette()
	keys := "tab/←/→ switch • ↑/↓ move • ? help • T theme • S save • q quit"
	if m.input.Active {
		keys = "enter submit • esc cancel • ctrl+u clear"
	}
	return lipgloss.NewStyle().
		Foreground(lipgloss.Color(p.Muted)).
		MarginTop(1).
		Render(keys)
}

func (m model) renderDashboard() string {
	p := m.palette()
	done := 0
	for _, t := range m.state.Todos {
		if t.Done {
			done++
		}
	}

	cards := []string{
		statCard("Todos", fmt.Sprintf("%d / %d done", done, len(m.state.Todos)), p),
		statCard("Notes", fmt.Sprintf("%d saved", len(m.state.Notes)), p),
		statCard("Jobs", fmt.Sprintf("%d running", countRunningJobs(m.jobs)), p),
		statCard("Uptime", time.Since(m.started).Round(time.Second).String(), p),
	}

	var cardRow string
	if m.width >= 92 {
		cardRow = lipgloss.JoinHorizontal(lipgloss.Top, cards...)
	} else {
		cardRow = lipgloss.JoinVertical(lipgloss.Left, cards...)
	}

	sysRows := [][]string{
		{"Go", runtime.Version()},
		{"OS/Arch", runtime.GOOS + "/" + runtime.GOARCH},
		{"Data", statePath()},
		{"Endpoint", m.state.Endpoint},
		{"Alt screen", fmt.Sprint(m.state.AltScreen)},
		{"Compact", fmt.Sprint(m.state.Compact)},
	}
	system := m.renderTable("System", []string{"Item", "Value"}, sysRows, []int{12, min(52, m.width-22)})

	logs := m.renderLogs()
	return lipgloss.JoinVertical(lipgloss.Left, cardRow, system, logs)
}

func statCard(name, value string, p palette) string {
	return lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Width(20).
		Padding(1, 2).
		MarginRight(1).
		Render(
			lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render(name) + "\n" +
				lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(value),
		)
}

func (m model) renderTodos() string {
	p := m.palette()
	if len(m.state.Todos) == 0 {
		return panel("Todos", "No todos yet. Press a to add one.", p, m.width)
	}

	var b strings.Builder
	for i, t := range m.state.Todos {
		cursor := "  "
		if i == m.cursor[m.screen] {
			cursor = "▸ "
		}
		check := "☐"
		style := lipgloss.NewStyle()
		if t.Done {
			check = "☑"
			style = style.Foreground(lipgloss.Color(p.Muted)).Strikethrough(true)
		}
		line := fmt.Sprintf("%s%s %s", cursor, check, t.Text)
		b.WriteString(style.Render(line))
		b.WriteString("\n")
	}
	help := "\nKeys: a add • space toggle • d delete • c clear done"
	return panel("Todos", b.String()+help, p, m.width)
}

func (m model) renderNotes() string {
	p := m.palette()
	if len(m.state.Notes) == 0 {
		return panel("Notes", "No notes yet. Press a to add one.", p, m.width)
	}

	i := m.cursor[m.screen]
	i = clamp(i, 0, len(m.state.Notes)-1)

	var list strings.Builder
	for idx, n := range m.state.Notes {
		cursor := "  "
		if idx == i {
			cursor = "▸ "
		}
		list.WriteString(fmt.Sprintf("%s%s  %s\n", cursor, n.Title, n.Created.Format("01-02 15:04")))
	}

	sideWidth := min(38, max(28, m.width/3))
	left := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Width(sideWidth).
		Padding(1, 2).
		Render(lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render("Notes") + "\n\n" + list.String())

	selected := m.state.Notes[i]
	body := selected.Body
	if !m.state.ShowNoteBody {
		body = "Press enter to show note body."
	}
	right := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Width(max(30, m.width-sideWidth-8)).
		Padding(1, 2).
		Render(
			lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(selected.Title) + "\n" +
				lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render(selected.Created.Format(time.RFC822)) + "\n\n" +
				wrap(body, max(24, m.width-sideWidth-14)) +
				"\n\n" +
				lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render("a add • enter show/hide • d delete"),
		)

	if m.width >= 82 {
		return lipgloss.JoinHorizontal(lipgloss.Top, left, right)
	}
	return lipgloss.JoinVertical(lipgloss.Left, left, right)
}

func (m model) renderHTTP() string {
	p := m.palette()
	status := "idle"
	if m.http.Loading {
		status = spinnerFrame(m.clock) + " loading"
	} else if m.http.Status != "" {
		status = m.http.Status
	}

	rows := [][]string{
		{"Endpoint", m.state.Endpoint},
		{"Status", status},
		{"Bytes", fmt.Sprintf("%d", m.http.Bytes)},
		{"Elapsed", m.http.Elapsed.Round(time.Millisecond).String()},
		{"Updated", formatMaybeTime(m.http.UpdatedAt)},
	}
	top := m.renderTable("HTTP Client", []string{"Field", "Value"}, rows, []int{12, min(58, m.width-22)})

	result := m.http.Result
	if result == "" {
		result = "No response yet."
	}
	result = truncateLines(result, max(8, m.height-15), max(36, m.width-10))
	box := panel("Response Preview", result+"\n\nKeys: e edit endpoint • f fetch", p, m.width)
	return lipgloss.JoinVertical(lipgloss.Left, top, box)
}

func (m model) renderJobs() string {
	p := m.palette()
	if len(m.jobs) == 0 {
		return panel("Jobs", "No jobs. Press n to add a simulated task.", p, m.width)
	}

	rows := make([][]string, 0, len(m.jobs))
	for i, j := range m.jobs {
		cursor := " "
		if i == m.cursor[m.screen] {
			cursor = "▸"
		}
		state := "paused"
		if j.Done {
			state = "done"
		} else if j.Running {
			state = "running"
		}
		rows = append(rows, []string{
			cursor,
			j.Name,
			progressBar(j.Percent, 24, p),
			fmt.Sprintf("%3.0f%%", j.Percent*100),
			state,
		})
	}

	table := m.renderTable("Simulated Jobs", []string{"", "Name", "Progress", "%", "State"}, rows, []int{2, 22, 28, 5, 8})
	help := lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render("n new • space pause/resume • r reset completed • d delete")
	return lipgloss.JoinVertical(lipgloss.Left, table, help)
}

type commandTemplate struct {
	Name string
	Kind promptKind
	Desc string
}

func commandTemplates() []commandTemplate {
	return []commandTemplate{
		{Name: "pkg install", Kind: promptPkgInstall, Desc: "Install a Termux package safely"},
		{Name: "curl download", Kind: promptCurlURL, Desc: "Download a URL with curl -fL"},
		{Name: "git clone", Kind: promptGitRepo, Desc: "Clone a Git repository"},
		{Name: "tar backup", Kind: promptTarSource, Desc: "Create backup.tar.gz from a path"},
		{Name: "python http server", Kind: promptHTTPPort, Desc: "Serve current directory over HTTP"},
		{Name: "ssh connect", Kind: promptSSHHost, Desc: "Build an ssh command"},
	}
}

func (m model) renderCommands() string {
	p := m.palette()
	templates := commandTemplates()

	rows := make([][]string, 0, len(templates))
	for i, t := range templates {
		cursor := " "
		if i == m.commandIndex {
			cursor = "▸"
		}
		rows = append(rows, []string{cursor, t.Name, t.Desc})
	}
	list := m.renderTable("Command Builder", []string{"", "Template", "Description"}, rows, []int{2, 20, min(48, m.width-34)})

	last := m.state.LastCommand
	if last == "" {
		last = "Select a template and press enter."
	}
	cmdBox := panel("Generated Command", last+"\n\nKeys: enter/e edit selected • c copy to clipboard", p, m.width)
	return lipgloss.JoinVertical(lipgloss.Left, list, cmdBox)
}

func (m model) renderSettings() string {
	p := m.palette()
	rows := [][]string{
		{"1 / t", "Theme", m.palette().Name},
		{"2 / c", "Compact mode", fmt.Sprint(m.state.Compact)},
		{"3 / a", "Alt screen", fmt.Sprint(m.state.AltScreen)},
		{"s", "Save", statePath()},
	}
	return m.renderTable("Settings", []string{"Key", "Setting", "Value"}, rows, []int{8, 18, min(48, m.width-34)}) +
		"\n" + lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render("Tip: if your terminal output looks odd, toggle Alt screen off and restart.")
}

func (m model) renderHelp() string {
	p := m.palette()
	help := `# Key Map

Global:
  q / ctrl+c       quit
  tab / right / l  next screen
  shift+tab / left / h previous screen
  ?                help
  T                cycle theme
  S                save state

Todos:
  a add, space toggle, d delete, c clear done

Notes:
  a add, enter show/hide, d delete

HTTP:
  e edit endpoint, f fetch

Jobs:
  n new job, space pause/resume, r reset done, d delete

Commands:
  enter generate command, c copy generated command

Bubble Tea idea:
  Model = state
  Update = events and commands
  View = render terminal UI`
	return panel("Help", help, p, m.width)
}

func (m model) renderInputBox() string {
	p := m.palette()
	value := m.input.Value
	if value == "" {
		value = lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render(m.input.Placeholder)
	}
	cursor := lipgloss.NewStyle().Foreground(lipgloss.Color(p.Accent)).Render("█")
	content := lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(m.input.Title) +
		"\n\n" + value + cursor +
		"\n\n" + lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render("enter submit • esc cancel • ctrl+u clear")
	return lipgloss.NewStyle().
		Border(lipgloss.DoubleBorder()).
		BorderForeground(lipgloss.Color(p.Accent)).
		Padding(1, 2).
		MarginTop(1).
		Width(min(m.width-4, 78)).
		Render(content)
}

func (m model) renderLogs() string {
	p := m.palette()
	if len(m.logs) == 0 {
		return panel("Event Log", "No events yet. Press r for a tip.", p, m.width)
	}
	return panel("Event Log", strings.Join(m.logs, "\n"), p, m.width)
}

func (m model) renderTable(title string, headers []string, rows [][]string, widths []int) string {
	p := m.palette()
	var b strings.Builder
	titleLine := lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(title)
	b.WriteString(titleLine)
	b.WriteString("\n\n")

	headerParts := make([]string, len(headers))
	for i, h := range headers {
		headerParts[i] = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(padOrTrim(h, widths[i]))
	}
	b.WriteString(strings.Join(headerParts, " "))
	b.WriteString("\n")
	b.WriteString(lipgloss.NewStyle().Foreground(lipgloss.Color(p.Muted)).Render(strings.Repeat("─", sumWidths(widths)+len(widths)-1)))
	b.WriteString("\n")

	for _, row := range rows {
		parts := make([]string, len(widths))
		for i := range widths {
			cell := ""
			if i < len(row) {
				cell = row[i]
			}
			parts[i] = padOrTrim(cell, widths[i])
		}
		b.WriteString(strings.Join(parts, " "))
		b.WriteString("\n")
	}

	return lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Padding(1, 2).
		MarginTop(1).
		Width(min(m.width-4, sumWidths(widths)+len(widths)+6)).
		Render(b.String())
}

func panel(title, content string, p palette, width int) string {
	titleLine := lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(p.Accent)).Render(title)
	return lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(lipgloss.Color(p.Soft)).
		Padding(1, 2).
		MarginTop(1).
		Width(max(40, min(width-4, 86))).
		Render(titleLine + "\n\n" + content)
}

func saveStateCmd(state appState) tea.Cmd {
	return func() tea.Msg {
		path := statePath()
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			return savedMsg{Path: path, Err: err}
		}
		tmp := path + ".tmp"
		data, err := json.MarshalIndent(state, "", "  ")
		if err != nil {
			return savedMsg{Path: path, Err: err}
		}
		if err := os.WriteFile(tmp, data, 0o644); err != nil {
			return savedMsg{Path: path, Err: err}
		}
		if err := os.Rename(tmp, path); err != nil {
			return savedMsg{Path: path, Err: err}
		}
		return savedMsg{Path: path, Err: nil}
	}
}

func loadState() (appState, error) {
	path := statePath()
	data, err := os.ReadFile(path)
	if err != nil {
		return appState{}, err
	}
	var s appState
	if err := json.Unmarshal(data, &s); err != nil {
		return appState{}, err
	}
	if strings.TrimSpace(s.Endpoint) == "" {
		s.Endpoint = "https://api.github.com"
	}
	if s.Theme < 0 || s.Theme >= len(palettes) {
		s.Theme = 0
	}
	return s, nil
}

func statePath() string {
	base := os.Getenv("XDG_DATA_HOME")
	if base == "" {
		home, err := os.UserHomeDir()
		if err != nil || home == "" {
			base = "."
		} else {
			base = filepath.Join(home, ".local", "share")
		}
	}
	return filepath.Join(base, "bubbletea-termux-demo", "state.json")
}

func fetchURLCmd(url string) tea.Cmd {
	return func() tea.Msg {
		start := time.Now()
		if strings.TrimSpace(url) == "" {
			return httpResultMsg{URL: url, Err: errors.New("empty URL")}
		}
		client := &http.Client{Timeout: 12 * time.Second}
		req, err := http.NewRequest(http.MethodGet, url, nil)
		if err != nil {
			return httpResultMsg{URL: url, Err: err}
		}
		req.Header.Set("User-Agent", "bubbletea-termux-demo/1.0")
		resp, err := client.Do(req)
		if err != nil {
			return httpResultMsg{URL: url, Elapsed: time.Since(start), Err: err}
		}
		defer resp.Body.Close()

		limited := io.LimitReader(resp.Body, 4096)
		body, err := io.ReadAll(limited)
		if err != nil {
			return httpResultMsg{URL: url, Status: resp.Status, Elapsed: time.Since(start), Err: err}
		}
		return httpResultMsg{
			URL:     url,
			Status:  resp.Status,
			Elapsed: time.Since(start),
			Bytes:   len(body),
			Body:    string(body),
			Err:     nil,
		}
	}
}

func isPrintableKey(s string) bool {
	if s == "" {
		return false
	}
	switch s {
	case "up", "down", "left", "right", "enter", "tab", "shift+tab", "esc",
		"backspace", "delete", "ctrl+c", "ctrl+u", "ctrl+h", "home", "end",
		"pgup", "pgdown":
		return false
	}
	// Bubble Tea v2 returns printable characters via String(). Keep this
	// conservative so special key names are not inserted into text fields.
	return utf8.RuneCountInString(s) == 1
}

func removeLastRune(s string) string {
	if s == "" {
		return ""
	}
	r := []rune(s)
	return string(r[:len(r)-1])
}

func shellQuote(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "''"
	}
	return "'" + strings.ReplaceAll(s, "'", "'\"'\"'") + "'"
}

func progressBar(percent float64, width int, p palette) string {
	_ = p
	percent = clampFloat(percent, 0, 1)
	filled := int(percent * float64(width))
	if filled > width {
		filled = width
	}
	return strings.Repeat("█", filled) + strings.Repeat("░", width-filled)
}

func spinnerFrame(t time.Time) string {
	frames := []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}
	idx := int(t.UnixMilli()/100) % len(frames)
	return frames[idx]
}

func padOrTrim(s string, width int) string {
	rs := []rune(stripNewlines(s))
	if len(rs) > width {
		if width <= 1 {
			return string(rs[:width])
		}
		return string(rs[:width-1]) + "…"
	}
	return string(rs) + strings.Repeat(" ", width-len(rs))
}

func stripNewlines(s string) string {
	s = strings.ReplaceAll(s, "\n", " ")
	s = strings.ReplaceAll(s, "\r", " ")
	return s
}

func sumWidths(widths []int) int {
	total := 0
	for _, w := range widths {
		total += w
	}
	return total
}

func wrap(s string, width int) string {
	if width <= 0 {
		return s
	}
	words := strings.Fields(s)
	if len(words) == 0 {
		return ""
	}
	var lines []string
	var line string
	for _, w := range words {
		if runeLen(line)+1+runeLen(w) > width {
			lines = append(lines, line)
			line = w
		} else if line == "" {
			line = w
		} else {
			line += " " + w
		}
	}
	if line != "" {
		lines = append(lines, line)
	}
	return strings.Join(lines, "\n")
}

func truncateLines(s string, maxLines, maxWidth int) string {
	lines := strings.Split(s, "\n")
	if len(lines) > maxLines {
		lines = lines[:maxLines]
		lines = append(lines, "…")
	}
	for i := range lines {
		lines[i] = padOrTrim(lines[i], maxWidth)
	}
	return strings.Join(lines, "\n")
}

func runeLen(s string) int {
	return utf8.RuneCountInString(s)
}

func countRunningJobs(jobs []Job) int {
	count := 0
	for _, j := range jobs {
		if j.Running && !j.Done {
			count++
		}
	}
	return count
}

func formatMaybeTime(t time.Time) string {
	if t.IsZero() {
		return "never"
	}
	return t.Format("15:04:05")
}

func randomTip() string {
	tips := []string{
		"Commands should return messages instead of mutating UI directly.",
		"Keep Update fast; do I/O inside tea.Cmd.",
		"Model can be split into child models when the app grows.",
		"View should be a pure render of your current state.",
		"Termux works best after pkg update && pkg upgrade.",
	}
	sort.Strings(tips)
	return tips[rand.Intn(len(tips))]
}

func clamp(v, low, high int) int {
	if high < low {
		return low
	}
	if v < low {
		return low
	}
	if v > high {
		return high
	}
	return v
}

func clampFloat(v, low, high float64) float64 {
	if v < low {
		return low
	}
	if v > high {
		return high
	}
	return v
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

pkg update
pkg install -y golang git unzip

echo
echo "Dependencies installed."
echo "Run the demo with:"
echo "  chmod +x run-termux.sh"
echo "  ./run-termux.sh"

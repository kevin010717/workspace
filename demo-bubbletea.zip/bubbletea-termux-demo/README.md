# Bubble Tea Termux Demo

这是一个功能较完整的 Bubble Tea v2 Termux 示例项目。

## 已锁定的有效依赖版本

```text
charm.land/bubbletea/v2 v2.0.7
charm.land/lipgloss/v2 v2.0.3
```

## Termux 安装与运行

```bash
pkg update
pkg install golang git unzip

unzip bubbletea-termux-demo-fixed.zip
cd bubbletea-termux-demo

go mod tidy
go run .
```

也可以使用项目中的启动脚本：

```bash
chmod +x run-termux.sh
./run-termux.sh
```

## 从旧版本目录直接修复

如果你已经进入之前解压的 `bubbletea-termux-demo` 目录，可以执行：

```bash
go mod edit -require=charm.land/bubbletea/v2@v2.0.7
go mod edit -require=charm.land/lipgloss/v2@v2.0.3
rm -f go.sum
go mod tidy
go run .
```

## 页面编号

```text
1 Dashboard
2 Todos
3 Notes
4 HTTP
5 Jobs
6 Commands
7 Settings
8 Help
```

在输入框关闭时，可以直接按 `1` 到 `8` 跳转页面。例如按 `3` 直接进入 Notes。

## 常用按键

```text
q / ctrl+c          退出
1 ... 8             直接跳转页面
tab / right / l     下一个页面
shift+tab / left/h  上一个页面
?                   帮助
T                   切换主题
S                   保存状态
```

页面内：

```text
Todos:    a 添加，space 切换完成，d 删除，c 清理已完成
Notes:    a 添加，enter 显示/隐藏正文，d 删除
HTTP:     e 修改 endpoint，f 请求
Jobs:     n 新任务，space 暂停/继续，r 重置完成任务，d 删除
Commands: enter 生成命令，c 复制命令
Settings: t 主题，c 紧凑模式，a Alt Screen
```

## 数据保存位置

```text
$XDG_DATA_HOME/bubbletea-termux-demo/state.json
```

未设置 `XDG_DATA_HOME` 时：

```text
~/.local/share/bubbletea-termux-demo/state.json
```

# Bubble Tea Termux Demo

这是一个面向 Termux 的 Bubble Tea v2 示例项目。它不是最小 Hello World，而是一个稍微完整的 TUI 工具箱，用来演示：

- 多页面导航
- Model / Update / View 架构
- 异步 Cmd：HTTP 请求、定时 tick、保存 JSON
- 表格、面板、进度条、日志、主题切换
- Todo、Notes、本地状态持久化
- 简单命令生成器
- Termux 运行注意事项

## 安装

```bash
pkg update
pkg install golang git
```

## 运行

```bash
unzip bubbletea-termux-demo.zip
cd bubbletea-termux-demo
go mod tidy
go run .
```

## 构建二进制

```bash
go build -o btdemo .
./btdemo
```

## 常用按键

全局：

```text
q / ctrl+c       退出
tab / right / l  下一个页面
shift+tab / left / h 上一个页面
?                帮助
T                切换主题
S                保存状态
```

页面功能：

```text
Todos:    a 添加，space 切换完成，d 删除，c 清理已完成
Notes:    a 添加，enter 显示/隐藏正文，d 删除
HTTP:     e 修改 endpoint，f 请求
Jobs:     n 新任务，space 暂停/继续，r 重置完成任务，d 删除
Commands: enter 生成命令，c 复制命令
Settings: t 主题，c 紧凑模式，a alt screen
```

## 数据保存位置

默认保存到：

```text
$XDG_DATA_HOME/bubbletea-termux-demo/state.json
```

如果没有设置 `XDG_DATA_HOME`，则保存到：

```text
~/.local/share/bubbletea-termux-demo/state.json
```

## 说明

Bubble Tea v2 使用新的导入路径：

```go
import tea "charm.land/bubbletea/v2"
```

本 Demo 额外使用 Lip Gloss v2 负责样式：

```go
import "charm.land/lipgloss/v2"
```

如果你想扩展它，建议先尝试：

1. 新增一个 screen；
2. 在 `updateKey` 里分发按键；
3. 写一个 `renderYourScreen()`；
4. 把需要耗时的工作放进 `tea.Cmd`。

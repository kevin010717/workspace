module bubbletea-termux-demo

go 1.23

require (
	charm.land/bubbletea/v2 v2.0.7
	charm.land/lipgloss/v2 v2.0.3
)

#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

echo "[1/3] Checking Go..."
command -v go >/dev/null 2>&1 || {
  echo "Go is missing. Run: pkg install golang git"
  exit 1
}

echo "[2/3] Resolving verified dependency versions..."
go mod edit -require=charm.land/bubbletea/v2@v2.0.7
go mod edit -require=charm.land/lipgloss/v2@v2.0.3
go mod tidy

echo "[3/3] Starting Bubble Tea Termux Demo..."
exec go run .

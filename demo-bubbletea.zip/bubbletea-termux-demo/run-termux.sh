#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "Installing recommended packages..."
pkg update
pkg install -y golang git

echo "Running Bubble Tea Termux Demo..."
go mod tidy
go run .
